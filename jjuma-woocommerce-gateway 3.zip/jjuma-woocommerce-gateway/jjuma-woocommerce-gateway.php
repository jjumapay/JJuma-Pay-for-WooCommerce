<?php
/**
 * Plugin Name: JJuma Pay for WooCommerce
 * Plugin URI:  https://jjuma.com
 * Description: Accept JJuma payments in WooCommerce and redirect customers to the hosted JJuma checkout.
 * Version:     1.1.0
 * Author:      JJuma
 * Author URI:  https://jjuma.com
 * Text Domain: jjuma-woocommerce-gateway
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 8.9
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('JJuma_WooCommerce_Gateway_Plugin')) {
    class JJuma_WooCommerce_Gateway_Plugin {
        const VERSION    = '1.1.0';
        const API_BASE   = 'https://api.jjuma.com';
        const GATEWAY_ID = 'jjuma_pay';

        public static function boot() {
            add_action('before_woocommerce_init', [__CLASS__, 'declare_compatibility']);
            add_action('plugins_loaded',           [__CLASS__, 'init_gateway'], 11);
            add_filter('woocommerce_payment_gateways', [__CLASS__, 'register_gateway']);
            add_filter('woocommerce_checkout_get_value', [__CLASS__, 'prefill_checkout_value'], 10, 2);
            add_action('rest_api_init',            [__CLASS__, 'register_routes']);
            add_action('woocommerce_blocks_loaded', [__CLASS__, 'register_blocks_integration']);
        }

        // ─────────────────────────────────────────────────────────────
        // HPOS / Custom Order Tables compatibility declaration
        // ─────────────────────────────────────────────────────────────
        public static function declare_compatibility() {
            if (!class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
                return;
            }
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        }

        // ─────────────────────────────────────────────────────────────
        // Gateway initialisation
        // ─────────────────────────────────────────────────────────────
        public static function init_gateway() {
            if (!class_exists('WC_Payment_Gateway')) {
                add_action('admin_notices', [__CLASS__, 'woocommerce_missing_notice']);
                return;
            }
            require_once __DIR__ . '/includes/class-wc-gateway-jjuma-pay.php';
        }

        public static function register_gateway($gateways) {
            $gateways[] = 'WC_Gateway_Jjuma_Pay';
            return $gateways;
        }

        // ─────────────────────────────────────────────────────────────
        // WooCommerce Blocks checkout integration
        // ─────────────────────────────────────────────────────────────
        public static function register_blocks_integration() {
            if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
                return;
            }
            require_once __DIR__ . '/includes/class-wc-gateway-jjuma-pay-blocks.php';
        }

        // ─────────────────────────────────────────────────────────────
        // REST API routes (webhook + callback)
        // ─────────────────────────────────────────────────────────────
        public static function register_routes() {
            register_rest_route('jjuma-pay/v1', '/woocommerce/callback', [
                'methods'             => ['GET', 'POST'],
                'callback'            => [__CLASS__, 'handle_callback'],
                'permission_callback' => '__return_true',
            ]);

            register_rest_route('jjuma-pay/v1', '/woocommerce/webhook', [
                'methods'             => ['POST'],
                'callback'            => [__CLASS__, 'handle_webhook'],
                'permission_callback' => '__return_true',
            ]);
        }

        // ─────────────────────────────────────────────────────────────
        // URL helpers
        // ─────────────────────────────────────────────────────────────
        public static function callback_url() {
            return esc_url_raw(rest_url('jjuma-pay/v1/woocommerce/callback'));
        }

        public static function webhook_url() {
            return esc_url_raw(rest_url('jjuma-pay/v1/woocommerce/webhook'));
        }

        public static function return_url() {
            return self::callback_url();
        }

        public static function cancel_url() {
            if (function_exists('wc_get_cart_url')) {
                return esc_url_raw(wc_get_cart_url());
            }
            return esc_url_raw(home_url('/'));
        }

        public static function ipn_url() {
            return self::webhook_url();
        }

        public static function api_base_url() {
            $settings = get_option('woocommerce_' . self::GATEWAY_ID . '_settings', []);
            $api_base = trim((string) ($settings['api_base_url'] ?? self::API_BASE));
            $api_base = untrailingslashit($api_base);
            return $api_base ?: self::API_BASE;
        }

        public static function webhook_secret() {
            $settings = get_option('woocommerce_' . self::GATEWAY_ID . '_settings', []);
            return trim((string) ($settings['webhook_secret'] ?? ''));
        }

        // ─────────────────────────────────────────────────────────────
        // Debug logging (admin-only, source: jjuma-pay)
        // ─────────────────────────────────────────────────────────────
        public static function should_log() {
            if (!function_exists('wc_get_logger')) {
                return false;
            }
            $settings   = get_option('woocommerce_' . self::GATEWAY_ID . '_settings', []);
            if (!empty($settings['debug_log_enabled']) && wc_string_to_bool((string) $settings['debug_log_enabled'])) {
                return true;
            }
            $debug_mode = get_option('woocommerce_enable_debug_mode', get_option('woocommerce_logging_enabled', 'no'));
            return (defined('WP_DEBUG') && WP_DEBUG) || wc_string_to_bool((string) $debug_mode);
        }

        public static function log_debug($message, array $context = []) {
            if (!self::should_log() || !function_exists('wc_get_logger')) {
                return;
            }
            $logger = wc_get_logger();
            $logger->debug($message, array_merge(['source' => 'jjuma-pay'], $context));
        }

        // ─────────────────────────────────────────────────────────────
        // Checkout field prefill for logged-in users
        // ─────────────────────────────────────────────────────────────
        private static function get_current_customer_profile() {
            $user = wp_get_current_user();
            if (!$user || !$user->exists()) {
                return [];
            }
            $first_name = get_user_meta($user->ID, 'billing_first_name', true);
            $last_name  = get_user_meta($user->ID, 'billing_last_name', true);
            $email      = get_user_meta($user->ID, 'billing_email', true);
            $phone      = get_user_meta($user->ID, 'billing_phone', true);
            return [
                'first_name' => trim((string) ($first_name ?: get_user_meta($user->ID, 'first_name', true) ?: $user->first_name)),
                'last_name'  => trim((string) ($last_name  ?: get_user_meta($user->ID, 'last_name', true)  ?: $user->last_name)),
                'email'      => sanitize_email($email ?: $user->user_email),
                'phone'      => trim((string) $phone),
            ];
        }

        public static function prefill_checkout_value($value, $input) {
            if (!function_exists('is_checkout') || !is_checkout() || is_admin() || !is_user_logged_in()) {
                return $value;
            }
            $profile = self::get_current_customer_profile();
            $input   = sanitize_key((string) $input);
            switch ($input) {
                case 'billing_first_name': return $value !== '' ? $value : ($profile['first_name'] ?? $value);
                case 'billing_last_name':  return $value !== '' ? $value : ($profile['last_name']  ?? $value);
                case 'billing_email':      return $value !== '' ? $value : ($profile['email']       ?? $value);
                case 'billing_phone':      return $value !== '' ? $value : ($profile['phone']       ?? $value);
                default:                   return $value;
            }
        }

        // ─────────────────────────────────────────────────────────────
        // Callback / Webhook handlers
        // ─────────────────────────────────────────────────────────────
        public static function handle_callback(WP_REST_Request $request) {
            return self::process_notification($request, true);
        }

        public static function handle_webhook(WP_REST_Request $request) {
            return self::process_notification($request, false);
        }

        private static function validate_webhook_signature(WP_REST_Request $request) {
            $secret = self::webhook_secret();
            if (!$secret) {
                return true; // No secret configured → skip signature check.
            }
            $signature = (string) $request->get_header('x-jjuma-signature');
            if (!$signature) {
                $signature = (string) $request->get_header('x-webhook-signature');
            }
            if (!$signature) {
                return true; // Signature header not present → accept (no secret required on JJuma side).
            }
            $raw_body = (string) $request->get_body();
            $expected = hash_hmac('sha256', $raw_body, $secret);
            return hash_equals($expected, trim($signature));
        }

        private static function process_notification(WP_REST_Request $request, $is_callback = false) {
            if (!function_exists('wc_get_order')) {
                return new WP_REST_Response(['success' => false, 'message' => 'WooCommerce is not active.'], 400);
            }

            if (!$is_callback && !self::validate_webhook_signature($request)) {
                return new WP_REST_Response(['success' => false, 'message' => 'Invalid webhook signature.'], 401);
            }

            $order_id       = absint($request->get_param('order_id') ?: $request->get_param('orderId'));
            $transaction_id = sanitize_text_field($request->get_param('transaction_id') ?: $request->get_param('transactionId') ?: $request->get_param('tx_ref') ?: $request->get_param('id') ?: '');
            $reference      = sanitize_text_field($request->get_param('reference') ?: $request->get_param('reference_code') ?: '');
            $status_text    = strtolower((string) ($request->get_param('status') ?: $request->get_param('payment_status') ?: ''));
            $payload        = $request->get_json_params();

            if (!$transaction_id && is_array($payload)) {
                $transaction_id = sanitize_text_field($payload['transaction_id'] ?? $payload['transactionId'] ?? $payload['id'] ?? '');
                $reference      = sanitize_text_field($payload['reference'] ?? $payload['reference_code'] ?? $reference);
                $status_text    = strtolower((string) ($payload['status'] ?? $status_text));
            }

            $order = $order_id ? wc_get_order($order_id) : null;
            if (!$order && $transaction_id) {
                $orders = wc_get_orders([
                    'limit'      => 1,
                    'meta_key'   => '_jjuma_transaction_id',
                    'meta_value' => $transaction_id,
                    'return'     => 'ids',
                ]);
                if (!empty($orders[0])) {
                    $order = wc_get_order($orders[0]);
                }
            }

            if (!$order) {
                return new WP_REST_Response(['success' => false, 'message' => 'Order not found.'], 404);
            }

            if ($order->is_paid() && $order->get_meta('_jjuma_payment_verified_at')) {
                self::log_debug('JJuma notification ignored — order already paid.', [
                    'order_id'       => $order->get_id(),
                    'transaction_id' => $transaction_id,
                    'is_callback'    => $is_callback ? 'yes' : 'no',
                ]);
                if ($is_callback && !wp_doing_ajax()) {
                    wp_safe_redirect(self::success_redirect_url($order));
                    exit;
                }
                return new WP_REST_Response(['success' => true, 'message' => 'Payment already processed.'], 200);
            }

            $verify = self::verify_transaction($transaction_id ?: (string) $order->get_meta('_jjuma_transaction_id'));
            if (is_wp_error($verify)) {
                $order->add_order_note('JJuma verification failed: ' . $verify->get_error_message());
                $order->save();
                return new WP_REST_Response(['success' => false, 'message' => $verify->get_error_message()], 400);
            }

            $verified_status = strtolower((string) ($verify['status'] ?? $verify['data']['status'] ?? $status_text));
            $transaction_id  = $transaction_id ?: sanitize_text_field($verify['transaction_id'] ?? $verify['data']['transaction_id'] ?? '');
            $reference       = $reference       ?: sanitize_text_field($verify['reference_code'] ?? $verify['reference'] ?? $verify['data']['reference_code'] ?? '');

            self::log_debug('JJuma verification status.', [
                'order_id'       => $order->get_id(),
                'transaction_id' => $transaction_id,
                'status'         => $verified_status,
                'is_callback'    => $is_callback ? 'yes' : 'no',
            ]);

            $order->update_meta_data('_jjuma_transaction_id', $transaction_id);
            $order->update_meta_data('_jjuma_reference', $reference);
            $order->update_meta_data('_jjuma_verified_payload', wp_json_encode($verify));

            if (in_array($verified_status, ['successful', 'success', 'completed', 'paid'], true)) {
                $order->update_meta_data('_jjuma_payment_verified_at', current_time('mysql'));
                $order->update_meta_data('_jjuma_checkout_state', 'successful');
                $order->update_meta_data('_jjuma_settlement_status', 'pending_settlement');
                $order->update_meta_data('_jjuma_settlement_release_at', gmdate('c', time() + (48 * HOUR_IN_SECONDS)));
                $order->update_meta_data('_jjuma_settlement_released_at', '');
                $order->update_meta_data('_jjuma_settlement_available_at', '');
                $order->update_meta_data('_jjuma_withdrawable_amount', '0');
                $order->save();
                if (!$order->is_paid()) {
                    $order->payment_complete($transaction_id);
                }
                $order->add_order_note(sprintf('JJuma payment verified. Transaction: %s Reference: %s', $transaction_id ?: '-', $reference ?: '-'));
                $order->save();
                if (function_exists('WC') && WC()->cart) {
                    WC()->cart->empty_cart();
                }
                if ($is_callback && !wp_doing_ajax()) {
                    wp_safe_redirect(self::success_redirect_url($order));
                    exit;
                }
                return new WP_REST_Response(['success' => true, 'message' => 'Payment verified.'], 200);
            }

            if (in_array($verified_status, ['failed', 'cancelled', 'canceled', 'expired'], true)) {
                $order->update_meta_data('_jjuma_checkout_state', $verified_status);
                $order->update_meta_data('_jjuma_settlement_status', $verified_status);
                $order->update_status('failed', 'JJuma payment not completed.');
                $order->save();
                if ($is_callback && !wp_doing_ajax()) {
                    $settings = get_option('woocommerce_' . self::GATEWAY_ID . '_settings', []);
                    $custom_cancel = trim((string) ($settings['cancel_redirect_url'] ?? ''));
                    if ($custom_cancel !== '') {
                        wp_safe_redirect(esc_url_raw($custom_cancel));
                    } else {
                        wp_safe_redirect($order->get_cancel_order_url());
                    }
                    exit;
                }
                return new WP_REST_Response(['success' => false, 'message' => 'Payment failed or cancelled.'], 200);
            }

            $order->update_status('on-hold', 'JJuma payment pending verification.');
            $order->update_meta_data('_jjuma_checkout_state', 'pending');
            if (!$order->get_meta('_jjuma_settlement_status')) {
                $order->update_meta_data('_jjuma_settlement_status', 'pending_settlement');
            }
            $order->save();
            if ($is_callback && !wp_doing_ajax()) {
                wp_safe_redirect($order->get_checkout_order_received_url());
                exit;
            }
            return new WP_REST_Response(['success' => true, 'message' => 'Payment is pending verification.'], 200);
        }

        private static function verify_transaction($transaction_id) {
            $transaction_id = trim((string) $transaction_id);
            if (!$transaction_id) {
                return new WP_Error('jjuma_missing_transaction', 'Missing transaction ID for verification.');
            }

            $settings   = get_option('woocommerce_' . self::GATEWAY_ID . '_settings', []);
            $secret     = trim((string) ($settings['secret_key'] ?? ''));
            if (!$secret) {
                $secret = trim((string) ($settings['public_key'] ?? ''));
            }
            if (!$secret) {
                return new WP_Error('jjuma_missing_secret', 'Please configure a JJuma Secret Key in WooCommerce settings.');
            }

            $verify_url = self::api_base_url() . '/api/v1/payments/verify/' . rawurlencode($transaction_id);
            self::log_debug('JJuma: verifying payment.', [
                'transaction_id' => $transaction_id,
                'verify_url'     => $verify_url,
            ]);

            $response = wp_remote_get($verify_url, [
                'timeout' => 45,
                'headers' => ['Authorization' => 'Bearer ' . $secret],
            ]);

            if (is_wp_error($response)) {
                return $response;
            }

            $status = (int) wp_remote_retrieve_response_code($response);
            $body   = json_decode(wp_remote_retrieve_body($response), true);
            if ($status < 200 || $status >= 300) {
                $message = $body['detail'] ?? $body['message'] ?? wp_remote_retrieve_response_message($response) ?: 'Unable to verify JJuma payment.';
                return new WP_Error('jjuma_verify_failed', $message);
            }

            return $body['data'] ?? $body;
        }

        private static function success_redirect_url($order) {
            $settings = get_option('woocommerce_' . self::GATEWAY_ID . '_settings', []);
            $custom_success = trim((string) ($settings['success_redirect_url'] ?? ''));
            if ($custom_success !== '') {
                return esc_url_raw($custom_success);
            }
            return esc_url_raw(home_url('/'));
        }

        // ─────────────────────────────────────────────────────────────
        // Admin notices
        // ─────────────────────────────────────────────────────────────
        public static function woocommerce_missing_notice() {
            echo '<div class="notice notice-warning"><p><strong>JJuma Pay for WooCommerce</strong> requires WooCommerce to be installed and active.</p></div>';
        }
    }
}

JJuma_WooCommerce_Gateway_Plugin::boot();
