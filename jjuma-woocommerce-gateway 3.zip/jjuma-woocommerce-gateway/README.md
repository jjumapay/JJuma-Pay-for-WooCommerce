# JJuma Pay for WooCommerce

This plugin adds JJuma Pay as a WooCommerce payment gateway and redirects customers to the hosted JJuma checkout.

## Features

- Payment method title: `JJuma Pay`
- Hosted checkout redirect
- Callback route for payment return handling
- Webhook route for server-to-server verification
- Order notes with JJuma transaction and reference IDs

## Installation

1. Copy the `jjuma-woocommerce-gateway` folder into your WordPress plugins directory.
2. Activate **JJuma Pay for WooCommerce** in WordPress.
3. Ensure WooCommerce is installed and active.
4. Open WooCommerce settings and configure the JJuma Pay gateway.

## Configuration

Required fields:

- Enable/Disable
- Title
- Description
- JJuma Public Key / API Key
- JJuma Secret Key
- Test Mode / Live Mode

Display-only fields:

- Callback URL
- Webhook URL

## Payment Flow

1. Customer places an order and selects JJuma Pay.
2. The plugin creates a JJuma payment session using `https://api.jjuma.com/api/v1/payments/create`.
3. The customer is redirected to the hosted checkout.
4. JJuma returns the customer to the callback URL.
5. The plugin verifies the transaction using `GET /api/v1/payments/verify/{transaction_id}`.
6. The WooCommerce order is marked paid.

## Webhook

Use the webhook URL shown in the settings panel for server-side payment notifications:

`/wp-json/jjuma-pay/v1/woocommerce/webhook`

## Callback

Use the callback URL shown in the settings panel for the customer return flow:

`/wp-json/jjuma-pay/v1/woocommerce/callback`

## Notes

- Keep secret keys on the server only.
- Do not expose API keys in frontend code.
- Verify payments before marking orders complete.
- The plugin uses `https://api.jjuma.com` as the production API base.
