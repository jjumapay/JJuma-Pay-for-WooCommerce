/**
 * JJuma Pay – WooCommerce Blocks checkout integration.
 * Registers the payment method so it appears in the Block-based checkout.
 */
( function ( wp, wc ) {
    'use strict';

    if ( ! wc || ! wc.wcBlocksRegistry || ! wc.wcSettings || ! wp || ! wp.element ) {
        return;
    }

    var settings        = wc.wcSettings.getSetting( 'jjuma_pay_data', {} );
    var createElement   = wp.element.createElement;
    var decodeEntities  = ( wp.htmlEntities && wp.htmlEntities.decodeEntities ) || function ( s ) { return s; };

    var labelText       = decodeEntities( settings.title )       || 'JJuma Pay';
    var descriptionText = decodeEntities( settings.description ) || 'Pay securely using JJuma Pay.';
    var iconUrl         = settings.icon_url || '';

    // Label shown in the payment method list.
    var Label = function () {
        return createElement(
            'span',
            { className: 'jjuma-pay-label', style: { display: 'flex', alignItems: 'center', gap: '8px' } },
            iconUrl
                ? createElement( 'img', {
                    src:   iconUrl,
                    alt:   labelText,
                    style: { maxHeight: '24px', maxWidth: '80px', display: 'inline-block' },
                } )
                : null,
            labelText
        );
    };

    // Content shown below the method when it is selected.
    var Content = function () {
        return createElement(
            'div',
            { className: 'jjuma-pay-blocks-payment-method__content' },
            createElement( 'p', { style: { margin: '8px 0 0' } }, descriptionText )
        );
    };

    wc.wcBlocksRegistry.registerPaymentMethod( {
        name:           'jjuma_pay',
        label:          createElement( Label ),
        ariaLabel:      labelText,
        content:        createElement( Content ),
        edit:           createElement( Content ),
        canMakePayment: function () { return true; },
        supports: {
            features: settings.supports || [ 'products' ],
        },
    } );
} )( window.wp, window.wc );
