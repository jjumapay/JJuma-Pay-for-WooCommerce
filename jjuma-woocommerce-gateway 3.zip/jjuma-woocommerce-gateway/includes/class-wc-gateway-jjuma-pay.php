<?php
if (!defined('ABSPATH')) {
    exit;
}

if (class_exists('WC_Payment_Gateway') && !class_exists('WC_Gateway_Jjuma_Pay')) {
    class WC_Gateway_Jjuma_Pay extends WC_Payment_Gateway {
        public function __construct() {
            $this->id                 = JJuma_WooCommerce_Gateway_Plugin::GATEWAY_ID;
            $this->method_title       = 'JJuma Pay';
            $this->method_description = 'Redirect customers to the hosted JJuma checkout and verify payment on callback/webhook.';
            $this->has_fields         = false;
            $this->supports           = ['products', 'refunds'];

            $this->init_form_fields();
            $this->init_settings();

            $this->title       = $this->get_option('title', 'JJuma Pay');
            $this->description = $this->get_option('description', 'Pay securely using JJuma Pay.');
            $this->enabled     = $this->get_option('enabled', 'no');
            $this->icon        = esc_url_raw($this->get_option('icon_url', ''));

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            add_filter('woocommerce_available_payment_gateways', [$this, 'force_default_gateway']);
            add_action('wp_enqueue_scripts', [$this, 'enqueue_checkout_scripts']);
        }

        public function init_form_fields() {
            $this->form_fields = [
                'enabled' => [
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable JJuma Pay',
                    'default' => 'no',
                ],
                'title' => [
                    'title'   => 'Title',
                    'type'    => 'text',
                    'default' => 'JJuma Pay',
                ],
                'description' => [
                    'title'   => 'Description',
                    'type'    => 'textarea',
                    'default' => 'Pay securely using JJuma Pay.',
                ],
                'icon_url' => [
                    'title'       => 'Icon / Logo URL',
                    'type'        => 'text',
                    'description' => 'Optional image URL shown next to the payment method.',
                    'default'     => '',
                ],
                'api_base_url' => [
                    'title'       => 'JJuma API Base URL',
                    'type'        => 'text',
                    'description' => 'Default: https://api.jjuma.com',
                    'default'     => JJuma_WooCommerce_Gateway_Plugin::API_BASE,
                ],
                'store_merchant_id' => [
                    'title'       => 'Store / Merchant ID',
                    'type'        => 'text',
                    'description' => 'Optional identifier for the store or merchant account.',
                    'default'     => '',
                ],
                'mode' => [
                    'title'   => 'Test Mode / Live Mode',
                    'type'    => 'select',
                    'default' => 'live',
                    'options' => [
                        'test' => 'Test Mode',
                        'live' => 'Live Mode',
                    ],
                ],
                'public_key' => [
                    'title'       => 'JJuma Public Key / API Key',
                    'type'        => 'text',
                    'description' => 'Legacy fallback public key. Used if the mode-specific key is blank.',
                    'default'     => '',
                ],
                'secret_key' => [
                    'title'       => 'JJuma Secret Key',
                    'type'        => 'password',
                    'description' => 'Legacy fallback secret key. Leave blank to keep existing saved secret.',
                    'default'     => '',
                    'custom_attributes' => ['placeholder' => 'Leave blank to keep existing secret'],
                ],
                'test_public_key' => [
                    'title'       => 'Test Public Key',
                    'type'        => 'text',
                    'description' => 'Used when Mode is set to Test Mode.',
                    'default'     => '',
                ],
                'test_secret_key' => [
                    'title'       => 'Test Secret Key',
                    'type'        => 'password',
                    'description' => 'Used when Mode is set to Test Mode.',
                    'default'     => '',
                    'custom_attributes' => ['placeholder' => 'Leave blank to keep existing secret'],
                ],
                'live_public_key' => [
                    'title'       => 'Live Public Key',
                    'type'        => 'text',
                    'description' => 'Used when Mode is set to Live Mode.',
                    'default'     => '',
                ],
                'live_secret_key' => [
                    'title'       => 'Live Secret Key',
                    'type'        => 'password',
                    'description' => 'Used when Mode is set to Live Mode.',
                    'default'     => '',
                    'custom_attributes' => ['placeholder' => 'Leave blank to keep existing secret'],
                ],
                'webhook_secret' => [
                    'title'       => 'Webhook Secret',
                    'type'        => 'password',
                    'description' => 'Optional. Leave blank to keep existing saved value.',
                    'default'     => '',
                    'custom_attributes' => ['placeholder' => 'Leave blank to keep existing secret'],
                ],
                'callback_url_display' => [
                    'title'             => 'Callback / Return URL',
                    'type'              => 'text',
                    'default'           => JJuma_WooCommerce_Gateway_Plugin::callback_url(),
                    'custom_attributes' => ['readonly' => 'readonly'],
                    'description'       => 'Use this URL as the redirect URL when creating the payment session.',
                ],
                'webhook_url_display' => [
                    'title'             => 'Webhook URL',
                    'type'              => 'text',
                    'default'           => JJuma_WooCommerce_Gateway_Plugin::webhook_url(),
                    'custom_attributes' => ['readonly' => 'readonly'],
                    'description'       => 'Use this URL for server-to-server payment notifications from JJuma.',
                ],
                'return_url_display' => [
                    'title'             => 'Return URL',
                    'type'              => 'text',
                    'default'           => JJuma_WooCommerce_Gateway_Plugin::return_url(),
                    'custom_attributes' => ['readonly' => 'readonly'],
                    'description'       => 'Customer return URL after payment.',
                ],
                'cancel_url_display' => [
                    'title'             => 'Cancel URL',
                    'type'              => 'text',
                    'default'           => JJuma_WooCommerce_Gateway_Plugin::cancel_url(),
                    'custom_attributes' => ['readonly' => 'readonly'],
                    'description'       => 'Customer cancel URL if checkout flow uses one.',
                ],
                'ipn_url_display' => [
                    'title'             => 'IPN / Callback URL',
                    'type'              => 'text',
                    'default'           => JJuma_WooCommerce_Gateway_Plugin::ipn_url(),
                    'custom_attributes' => ['readonly' => 'readonly'],
                    'description'       => 'Use this URL for webhook or IPN notifications.',
                ],
                'debug_log_enabled' => [
                    'title'   => 'Debug Logging',
                    'type'    => 'checkbox',
                    'label'   => 'Enable debug log (WooCommerce > Status > Logs, source: jjuma-pay)',
                    'default' => 'yes',
                ],
                'success_redirect_url' => [
                    'title'       => 'Custom Success Redirect URL',
                    'type'        => 'text',
                    'description' => 'Optional. Redirect customer here after successful payment. If blank, defaults to merchant website homepage.',
                    'default'     => '',
                ],
                'cancel_redirect_url' => [
                    'title'       => 'Custom Cancel Redirect URL',
                    'type'        => 'text',
                    'description' => 'Optional. Redirect customer here if payment is cancelled or fails. If blank, defaults to WooCommerce default cart/checkout fallback.',
                    'default'     => '',
                ],
            ];
        }

        public function admin_options() {
            echo '<h2>JJuma Pay for WooCommerce</h2>';
            echo '<p>Configure the JJuma checkout session and verification settings below.</p>';
            $this->render_status_panel();
            parent::admin_options();
        }

        private function render_status_panel() {
            $api_base          = trim((string) $this->get_option('api_base_url', JJuma_WooCommerce_Gateway_Plugin::API_BASE));
            $mode              = strtolower(trim((string) $this->get_option('mode', 'live')));
            $public_key        = $this->get_mode_public_key($mode);
            $secret_key        = $this->get_mode_secret_key($mode);
            $store_merchant_id = $this->get_setting_value(['store_merchant_id', 'merchant_id'], '');
            $debug_enabled     = wc_string_to_bool((string) $this->get_option('debug_log_enabled', 'no'));
            $callback_url      = JJuma_WooCommerce_Gateway_Plugin::callback_url();
            $return_url        = JJuma_WooCommerce_Gateway_Plugin::return_url();
            $cancel_url        = JJuma_WooCommerce_Gateway_Plugin::cancel_url();
            $webhook_url       = JJuma_WooCommerce_Gateway_Plugin::webhook_url();
            $ipn_url           = JJuma_WooCommerce_Gateway_Plugin::ipn_url();

            echo '<div class="notice inline" style="margin:16px 0;padding:16px;background:#fff;border:1px solid #dcdcde;">';
            echo '<strong>JJuma Pay Status</strong>';
            echo '<table class="form-table" style="margin-top:12px;">';
            echo '<tr><th scope="row">API Base URL</th><td>' . esc_html($api_base ? 'set' : 'missing') . '<br><code>' . esc_html($api_base ?: 'Missing') . '</code></td></tr>';
            echo '<tr><th scope="row">Public Key (' . esc_html($mode) . ')</th><td>' . esc_html($public_key ? 'set' : 'missing') . '</td></tr>';
            echo '<tr><th scope="row">Secret Key (' . esc_html($mode) . ')</th><td>' . esc_html($secret_key ? 'set' : 'missing') . '</td></tr>';
            echo '<tr><th scope="row">Webhook URL</th><td>' . $this->render_copyable_url($webhook_url) . '</td></tr>';
            echo '<tr><th scope="row">Callback / Return URL</th><td>' . $this->render_copyable_url($callback_url) . '</td></tr>';
            echo '<tr><th scope="row">Cancel URL</th><td>' . $this->render_copyable_url($cancel_url) . '</td></tr>';
            echo '<tr><th scope="row">IPN URL</th><td>' . $this->render_copyable_url($ipn_url) . '</td></tr>';
            echo '<tr><th scope="row">Store / Merchant ID</th><td>' . esc_html($store_merchant_id !== '' ? 'optional, set' : 'optional, not set') . '</td></tr>';
            echo '<tr><th scope="row">Debug Logging</th><td>' . esc_html($debug_enabled ? 'enabled' : 'disabled') . '</td></tr>';
            echo '</table>';
            echo '<p class="description">Secret values are never shown here. Leave blank to keep the existing saved secret.</p>';
            echo '</div>';
        }

        private function render_copyable_url($value) {
            $value = trim((string) $value);
            if ($value === '') {
                return '<code>Missing</code>';
            }
            return '<code style="word-break:break-all;">' . esc_html($value) . '</code> <button type="button" class="button button-small" onclick="navigator.clipboard.writeText(this.previousElementSibling.textContent.trim())">Copy</button>';
        }

        public function payment_fields() {
            if ($this->description) {
                echo wp_kses_post(wpautop(wptexturize($this->description)));
            }
        }

        private function log_debug($message, array $context = []) {
            JJuma_WooCommerce_Gateway_Plugin::log_debug($message, $context);
        }

        private function log_config_error($reason, array $context = []) {
            $this->log_debug('JJuma Pay config error: ' . $reason, $context);
        }

        private function get_setting_value(array $keys, $default = '') {
            foreach ($keys as $key) {
                $value = $this->get_option($key, null);
                if ($value !== null && $value !== '') {
                    return trim((string) $value);
                }
            }
            return $default;
        }

        private function get_mode_setting_value(array $mode_keys, array $legacy_keys = [], $default = '') {
            foreach ($mode_keys as $key) {
                $value = $this->get_option($key, null);
                if ($value !== null && $value !== '') {
                    return trim((string) $value);
                }
            }
            foreach ($legacy_keys as $key) {
                $value = $this->get_option($key, null);
                if ($value !== null && $value !== '') {
                    return trim((string) $value);
                }
            }
            return $default;
        }

        private function get_mode_public_key($mode = '') {
            $mode = strtolower(trim((string) ($mode ?: $this->get_option('mode', 'live'))));
            return $this->get_mode_setting_value([$mode . '_public_key'], ['public_key']);
        }

        private function get_mode_secret_key($mode = '') {
            $mode = strtolower(trim((string) ($mode ?: $this->get_option('mode', 'live'))));
            return $this->get_mode_setting_value([$mode . '_secret_key'], ['secret_key']);
        }

        private function get_checkout_state($order) {
            if (!$order || !is_object($order)) {
                return '';
            }
            return strtolower(trim((string) $order->get_meta('_jjuma_checkout_state')));
        }

        private function is_reusable_checkout_state($state) {
            $state = strtolower(trim((string) $state));
            return $state === '' || in_array($state, ['pending', 'created', 'active', 'processing'], true);
        }

        private function sanitize_payload_for_log(array $payload) {
            $safe = $payload;
            unset($safe['secret_key'], $safe['public_key'], $safe['api_key'], $safe['authorization'], $safe['Authorization']);
            return $safe;
        }

        /**
         * Validate only truly required fields.
         * - api_base_url: required
         * - public_key OR secret_key: at least one required
         * - amount > 0: required
         * - currency: required
         * - customer_name: required
         * - customer_email: optional (guest checkout may not have email)
         * - store_merchant_id: OPTIONAL, never blocks checkout
         * - webhook_secret: OPTIONAL, never blocks checkout
         * - Local/HTTP URLs are allowed (dev environments)
         */
        private function validate_checkout_configuration($order, $customer, $payload) {
            $api_base      = trim((string) $this->get_option('api_base_url', JJuma_WooCommerce_Gateway_Plugin::API_BASE));
            $mode          = strtolower(trim((string) $this->get_option('mode', 'live')));
            $public_key    = $this->get_mode_public_key($mode);
            $secret_key    = $this->get_mode_secret_key($mode);
            $currency      = trim((string) ($payload['currency'] ?? ''));
            $amount        = floatval($payload['amount'] ?? 0);
            $customer_name = trim((string) ($customer['customer_name'] ?? ''));
            $enabled       = wc_string_to_bool((string) $this->get_option('enabled', 'no'));

            if (!$enabled) {
                $this->log_config_error('gateway_disabled', ['order_id' => $order ? $order->get_id() : '']);
                return new WP_Error('jjuma_disabled', 'JJuma Pay is not configured correctly. Please contact the store owner.');
            }

            // Accept any non-empty URL string (including http:// and local URLs).
            if (!$api_base) {
                $this->log_config_error('missing_api_base_url', ['order_id' => $order ? $order->get_id() : '']);
                return new WP_Error('jjuma_missing_api_base', 'JJuma Pay is not configured correctly. Please contact the store owner.');
            }

            if (!$public_key && !$secret_key) {
                $this->log_config_error('missing_api_key', [
                    'order_id'       => $order ? $order->get_id() : '',
                    'has_public_key' => false,
                    'has_secret_key' => false,
                ]);
                return new WP_Error('jjuma_missing_api_key', 'JJuma Pay is not configured correctly. Please contact the store owner.');
            }

            if ($amount <= 0) {
                $this->log_config_error('invalid_order_amount', ['order_id' => $order ? $order->get_id() : '', 'amount' => $amount]);
                return new WP_Error('jjuma_invalid_amount', 'JJuma Pay is not configured correctly. Please contact the store owner.');
            }

            if (!$currency) {
                $this->log_config_error('missing_currency', ['order_id' => $order ? $order->get_id() : '']);
                return new WP_Error('jjuma_missing_currency', 'JJuma Pay is not configured correctly. Please contact the store owner.');
            }

            // customer_name is required by the JJuma API.
            if (!$customer_name) {
                $this->log_config_error('missing_customer_name', ['order_id' => $order ? $order->get_id() : '']);
                return new WP_Error('jjuma_missing_customer_name', 'JJuma Pay: Please enter your name to continue.');
            }

            // store_merchant_id is ALWAYS optional — log only, never block.
            $store_merchant_id = $this->get_setting_value(['store_merchant_id', 'merchant_id'], '');
            if ($store_merchant_id === '') {
                $this->log_debug('JJuma Pay: store_merchant_id is optional and not set. Checkout continues.', [
                    'order_id' => $order ? $order->get_id() : '',
                ]);
            }

            return true;
        }

        /**
         * Preserve secret_key and webhook_secret when admin leaves field blank.
         */
        public function process_admin_options() {
            foreach (['secret_key', 'webhook_secret', 'test_secret_key', 'live_secret_key'] as $field_name) {
                $field_key = $this->get_field_key($field_name);
                if (isset($_POST[$field_key])) {
                    $submitted = trim((string) wp_unslash($_POST[$field_key]));
                    if ($submitted === '') {
                        $existing = $this->get_option($field_name, '');
                        if ($existing !== '') {
                            $_POST[$field_key] = $existing;
                        }
                    }
                }
            }

            // Legacy merchant_id field compatibility.
            $store_field  = $this->get_field_key('store_merchant_id');
            $legacy_field = $this->get_field_key('merchant_id');
            if (!isset($_POST[$store_field]) && isset($_POST[$legacy_field])) {
                $_POST[$store_field] = wp_unslash($_POST[$legacy_field]);
            }

            return parent::process_admin_options();
        }

        public function process_payment($order_id) {
            $logger = function_exists('wc_get_logger') ? wc_get_logger() : null;
            $log_ctx = ['source' => 'jjuma-pay'];

            try {
                $order = wc_get_order($order_id);
                if (!$order) {
                    if ($logger) {
                        $logger->error('JJuma Pay: Unable to load order.', array_merge($log_ctx, ['order_id' => $order_id]));
                    }
                    wc_add_notice('Unable to load the order.', 'error');
                    return ['result' => 'fail'];
                }

                $this->log_debug('JJuma Pay: process_payment called.', ['order_id' => $order->get_id()]);

                $saved_payment_url = esc_url_raw((string) $order->get_meta('_jjuma_payment_url'));
                $saved_state = $this->get_checkout_state($order);
                if ($saved_payment_url && $this->is_reusable_checkout_state($saved_state)) {
                    $saved_transaction_id = sanitize_text_field((string) $order->get_meta('_jjuma_transaction_id'));
                    $saved_reference = sanitize_text_field((string) $order->get_meta('_jjuma_reference'));
                    $this->log_debug('JJuma Pay: reusing existing checkout session.', [
                        'order_id' => $order->get_id(),
                        'transaction_id' => $saved_transaction_id,
                        'reference' => $saved_reference,
                        'checkout_url' => $saved_payment_url,
                        'state' => $saved_state ?: 'pending',
                    ]);
                    return [
                        'result'   => 'success',
                        'redirect' => esc_url_raw($saved_payment_url),
                    ];
                }

                $customer    = $this->build_customer_payload($order);
                $callback_url = JJuma_WooCommerce_Gateway_Plugin::callback_url() . '?order_id=' . rawurlencode((string) $order->get_id());
                $webhook_url  = JJuma_WooCommerce_Gateway_Plugin::webhook_url();
                $return_url   = JJuma_WooCommerce_Gateway_Plugin::return_url() . '?order_id=' . rawurlencode((string) $order->get_id());
                $cancel_url   = JJuma_WooCommerce_Gateway_Plugin::cancel_url();

                $custom_success_url = trim((string) $this->get_option('success_redirect_url', ''));
                $success_redirect_url = $custom_success_url !== '' ? esc_url_raw($custom_success_url) : esc_url_raw(home_url('/'));

                $custom_cancel_url = trim((string) $this->get_option('cancel_redirect_url', ''));
                $cancel_redirect_url = $custom_cancel_url !== '' ? esc_url_raw($custom_cancel_url) : esc_url_raw($order->get_cancel_order_url());

                // Build order items summary (safe, no PII).
                $items_summary = [];
                foreach ($order->get_items() as $item) {
                    $items_summary[] = sanitize_text_field($item->get_name()) . ' x' . $item->get_quantity();
                }
                $order_items_str = implode(', ', array_slice($items_summary, 0, 5));
                if (count($items_summary) > 5) {
                    $order_items_str .= ' …';
                }

                // Build address strings.
                $billing_addr = '';
                $b_addr1  = trim((string) $order->get_billing_address_1());
                $b_addr2  = trim((string) $order->get_billing_address_2());
                $b_city   = trim((string) $order->get_billing_city());
                $b_country= trim((string) $order->get_billing_country());
                $billing_parts = array_filter([$b_addr1, $b_addr2, $b_city, $b_country]);
                if ($billing_parts) {
                    $billing_addr = implode(', ', $billing_parts);
                }

                $shipping_addr = '';
                $s_addr1  = trim((string) $order->get_shipping_address_1());
                $s_addr2  = trim((string) $order->get_shipping_address_2());
                $s_city   = trim((string) $order->get_shipping_city());
                $s_country= trim((string) $order->get_shipping_country());
                $shipping_parts = array_filter([$s_addr1, $s_addr2, $s_city, $s_country]);
                if ($shipping_parts) {
                    $shipping_addr = implode(', ', $shipping_parts);
                }

                $payload = [
                    'amount'               => (float) $order->get_total(),
                    'currency'             => $order->get_currency() ?: get_woocommerce_currency(),
                    'description'          => sprintf('WooCommerce Order #%s', $order->get_order_number()),
                    'customer_name'        => $customer['customer_name'],
                    'customer_email'       => $customer['customer_email'],
                    'customer_phone'       => $customer['customer_phone'],
                    'source'               => 'woocommerce',
                    'external_order_id'    => (string) $order->get_id(),
                    'idempotency_key'      => 'woocommerce-order-' . $order->get_id(),
                    'hidden_from_payment_links' => true,
                    'is_system_link'       => true,
                    'redirect_url'         => $return_url,
                    'webhook_url'          => $webhook_url,
                    'order_id'             => (string) $order->get_id(),
                    'order_number'         => (string) $order->get_order_number(),
                    'success_redirect_url' => $success_redirect_url,
                    'cancel_redirect_url'  => $cancel_redirect_url,
                    'callback_url'         => $callback_url,
                    'merchant_site_url'    => esc_url_raw(home_url('/')),
                    'metadata'             => [
                        'source'               => 'woocommerce',
                        'platform'             => 'woocommerce',
                        'external_order_id'    => (string) $order->get_id(),
                        'woocommerce_order_id' => (string) $order->get_id(),
                        'idempotency_key'      => 'woocommerce-order-' . $order->get_id(),
                        'order_id'             => (string) $order->get_id(),
                        'order_number'         => (string) $order->get_order_number(),
                        'first_name'           => sanitize_text_field($order->get_billing_first_name()),
                        'last_name'            => sanitize_text_field($order->get_billing_last_name()),
                        'billing_email'        => sanitize_email($order->get_billing_email()),
                        'billing_phone'        => sanitize_text_field($order->get_billing_phone()),
                        'billing_address'      => $billing_addr,
                        'shipping_address'     => $shipping_addr,
                        'order_items_summary'  => $order_items_str,
                        'order_total'          => (string) $order->get_total(),
                        'currency'             => $order->get_currency() ?: get_woocommerce_currency(),
                        'merchant_name'        => get_bloginfo('name'),
                        'site_url'             => home_url('/'),
                        'callback_url'         => $callback_url,
                        'return_url'           => $return_url,
                        'cancel_url'           => $cancel_url,
                        'webhook_url'          => $webhook_url,
                        'success_redirect_url' => $success_redirect_url,
                        'cancel_redirect_url'  => $cancel_redirect_url,
                        'merchant_site_url'    => home_url('/'),
                    ],
                ];

                $store_merchant_id = $this->get_setting_value(['store_merchant_id', 'merchant_id'], '');
                if ($store_merchant_id !== '') {
                    $payload['store_merchant_id']             = $store_merchant_id;
                    $payload['merchant_id']                   = $store_merchant_id;
                    $payload['store_id']                      = $store_merchant_id;
                    $payload['metadata']['store_merchant_id'] = $store_merchant_id;
                    $payload['metadata']['merchant_id']       = $store_merchant_id;
                }

                $validation = $this->validate_checkout_configuration($order, $customer, $payload);
                if (is_wp_error($validation)) {
                    $message = $validation->get_error_message();
                    $this->log_debug('JJuma Pay: checkout validation failed.', [
                        'order_id'    => $order->get_id(),
                        'error_code'  => $validation->get_error_code(),
                        'error'       => $message,
                    ]);
                    wc_add_notice($message, 'error');
                    return ['result' => 'fail'];
                }

                $this->log_debug('JJuma Pay: creating checkout session.', [
                    'order_id' => $order->get_id(),
                    'amount'   => (string) $payload['amount'],
                    'currency' => $payload['currency'],
                    'payload'  => $this->sanitize_payload_for_log($payload),
                ]);

                $session = $this->create_payment_session($payload);
                if (is_wp_error($session)) {
                    $error_message = $session->get_error_message();
                    $order->add_order_note('JJuma checkout creation failed: ' . $error_message);
                    $order->save();
                    $this->log_debug('JJuma Pay: checkout session creation failed.', [
                        'order_id' => $order->get_id(),
                        'error'    => $error_message,
                    ]);
                    wc_add_notice('Payment could not be started. Please try again or contact the store owner.', 'error');
                    return ['result' => 'fail'];
                }

                $payment_url    = $session['payment_url'] ?? '';
                $transaction_id = sanitize_text_field($session['transaction_id'] ?? '');
                $reference      = sanitize_text_field($session['reference'] ?? '');

                if (!$payment_url) {
                    $this->log_debug('JJuma Pay: response missing checkout URL.', [
                        'order_id' => $order->get_id(),
                        'session'  => $session,
                    ]);
                    $order->add_order_note('JJuma checkout response did not include a payment URL.');
                    $order->save();
                    wc_add_notice('Payment could not be started. Please try again or contact the store owner.', 'error');
                    return ['result' => 'fail'];
                }

                // Append autofill query params so the JJuma checkout pre-fills customer details.
                $autofill_params = array_filter([
                    'sender_name'  => $customer['customer_name'],
                    'sender_email' => $customer['customer_email'],
                    'sender_phone' => $customer['customer_phone'],
                ]);
                if ($autofill_params) {
                    $payment_url = add_query_arg(
                        $autofill_params,
                        esc_url_raw($payment_url)
                    );
                }

                $this->log_debug('JJuma Pay: checkout URL with autofill params built.', [
                    'order_id'    => $order->get_id(),
                    'checkout_url'=> $payment_url,
                ]);

                // Save JJuma references into order meta (HPOS-compatible).
                $order->update_meta_data('_jjuma_transaction_id', $transaction_id);
                $order->update_meta_data('_jjuma_reference', $reference);
                $order->update_meta_data('_jjuma_payment_url', esc_url_raw($payment_url));
                $order->update_meta_data('_jjuma_mode', sanitize_text_field($this->get_option('mode', 'live')));
                $order->update_meta_data('_jjuma_checkout_state', 'pending');
                $order->update_meta_data('_jjuma_source', 'woocommerce');
                $order->update_meta_data('_jjuma_external_order_id', (string) $order->get_id());
                $order->update_meta_data('_jjuma_idempotency_key', 'woocommerce-order-' . $order->get_id());
                if (!empty($session['payment_link_id'])) {
                    $order->update_meta_data('_jjuma_payment_link_id', sanitize_text_field($session['payment_link_id']));
                }
                $order->update_status('pending', 'JJuma Pay: awaiting payment confirmation.');
                $order->add_order_note(sprintf(
                    'JJuma checkout created. Transaction: %s Reference: %s Checkout URL: %s',
                    $transaction_id ?: '-',
                    $reference ?: '-',
                    $payment_url
                ));
                $order->save();

                $this->log_debug('JJuma Pay: checkout session created successfully.', [
                    'order_id'       => $order->get_id(),
                    'transaction_id' => $transaction_id,
                    'reference'      => $reference,
                    'checkout_url'   => $payment_url,
                ]);

                return [
                    'result'   => 'success',
                    'redirect' => esc_url_raw($payment_url),
                ];

            } catch (Throwable $e) {
                $this->log_debug('JJuma Pay: exception in process_payment.', [
                    'order_id' => $order_id,
                    'error'    => $e->getMessage(),
                    'trace'    => $e->getTraceAsString(),
                ]);
                wc_add_notice('JJuma Pay is not configured correctly. Please contact the store owner.', 'error');
                return ['result' => 'fail'];
            }
        }

        private function get_current_customer_profile() {
            $user = wp_get_current_user();
            if (!$user || !$user->exists()) {
                return [];
            }
            $first_name = get_user_meta($user->ID, 'billing_first_name', true);
            $last_name  = get_user_meta($user->ID, 'billing_last_name', true);
            $email      = get_user_meta($user->ID, 'billing_email', true);
            $phone      = get_user_meta($user->ID, 'billing_phone', true);
            return [
                'first_name' => trim((string) ($first_name ?: get_user_meta($user->ID, 'first_name', true) ?: $user->first_name)),
                'last_name'  => trim((string) ($last_name  ?: get_user_meta($user->ID, 'last_name', true)  ?: $user->last_name)),
                'email'      => sanitize_email($email ?: $user->user_email),
                'phone'      => trim((string) $phone),
            ];
        }

        private function build_customer_payload($order = null) {
            $profile    = $this->get_current_customer_profile();
            $first_name = '';
            $last_name  = '';
            $email      = '';
            $phone      = '';

            if ($order) {
                $first_name = trim((string) $order->get_billing_first_name());
                $last_name  = trim((string) $order->get_billing_last_name());
                $email      = sanitize_email($order->get_billing_email());
                $phone      = trim((string) $order->get_billing_phone());
            }

            if (!$first_name) $first_name = $profile['first_name'] ?? '';
            if (!$last_name)  $last_name  = $profile['last_name']  ?? '';
            if (!$email)      $email      = $profile['email']       ?? '';
            if (!$phone)      $phone      = $profile['phone']       ?? '';

            $full_name = trim($first_name . ' ' . $last_name);
            if (!$full_name && $order) {
                $full_name = trim((string) $order->get_formatted_billing_full_name());
            }
            if (!$full_name) {
                $full_name = trim((string) (($profile['first_name'] ?? '') . ' ' . ($profile['last_name'] ?? '')));
            }
            // Final fallback: use email prefix as name so the API gets something.
            if (!$full_name && $email) {
                $full_name = sanitize_text_field(strstr($email, '@', true) ?: $email);
            }

            return [
                'customer_name'  => $full_name ?: 'Customer',
                'customer_email' => $email,
                'customer_phone' => $phone,
            ];
        }

        /**
         * Call POST /api/v1/payments/create and return parsed session data or WP_Error.
         */
        private function create_payment_session(array $payload) {
            $mode = strtolower(trim((string) $this->get_option('mode', 'live')));
            $api_key = $this->get_mode_public_key($mode);
            if (!$api_key) {
                $api_key = $this->get_mode_secret_key($mode);
            }
            if (!$api_key) {
                $this->log_config_error('missing_api_key_for_session_creation');
                return new WP_Error('jjuma_missing_key', 'Please configure the mode-specific JJuma Public Key or Secret Key in WooCommerce settings.');
            }

            $api_base    = trim((string) $this->get_option('api_base_url', JJuma_WooCommerce_Gateway_Plugin::API_BASE));
            $api_base    = untrailingslashit($api_base ?: JJuma_WooCommerce_Gateway_Plugin::API_BASE);
            $request_url = $api_base . '/api/v1/payments/create';

            $this->log_debug('JJuma Pay: sending checkout creation request.', [
                'request_url' => $request_url,
                'order_id'    => $payload['metadata']['order_id'] ?? '',
                'amount'      => (string) ($payload['amount'] ?? ''),
                'currency'    => $payload['currency'] ?? '',
                'payload'     => $this->sanitize_payload_for_log($payload),
            ]);

            $response = wp_remote_post($request_url, [
                'timeout' => 45,
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ],
                'body'          => wp_json_encode($payload),
                'sslverify'     => !defined('WP_DEBUG') || !WP_DEBUG,
            ]);

            if (is_wp_error($response)) {
                $this->log_debug('JJuma Pay: HTTP transport error.', [
                    'request_url' => $request_url,
                    'error'       => $response->get_error_message(),
                ]);
                return $response;
            }

            $status   = (int) wp_remote_retrieve_response_code($response);
            $raw_body = (string) wp_remote_retrieve_body($response);
            $body     = json_decode($raw_body, true);
            if (!is_array($body)) {
                $body = ['raw' => $raw_body];
            }

            $this->log_debug('JJuma Pay: checkout creation response.', [
                'request_url' => $request_url,
                'http_status' => $status,
                'response'    => $body,
            ]);

            if ($status < 200 || $status >= 300) {
                $message = $body['detail'] ?? $body['message'] ?? $body['error'] ?? wp_remote_retrieve_response_message($response) ?: 'JJuma checkout creation failed.';
                return new WP_Error('jjuma_checkout_failed', $message);
            }

            // Parse checkout URL from all possible response fields.
            $data        = $body['data'] ?? $body;
            $payment_url = '';
            $candidates  = [
                $data['checkout_url']  ?? '',
                $data['payment_url']   ?? '',
                $data['redirect_url']  ?? '',
                $data['url']           ?? '',
                $data['payment']       ?? '',
                $data['payment_link']  ?? '',
                $data['checkoutUrl']   ?? '',
                $data['paymentUrl']    ?? '',
                $data['redirectUrl']   ?? '',
                $data['paymentLink']   ?? '',
                $body['checkout_url']  ?? '',
                $body['payment_url']   ?? '',
                $body['redirect_url']  ?? '',
                $body['url']           ?? '',
                $body['payment']       ?? '',
                $body['payment_link']  ?? '',
            ];
            foreach ($candidates as $candidate) {
                $candidate = trim((string) $candidate);
                if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_URL)) {
                    $payment_url = $candidate;
                    break;
                }
            }

            if (!$payment_url) {
                $this->log_debug('JJuma Pay: checkout URL not found in response.', [
                    'request_url' => $request_url,
                    'http_status' => $status,
                    'response'    => $body,
                ]);
                return new WP_Error('jjuma_missing_payment_url', 'JJuma did not return a payment URL.');
            }

            $transaction_id = sanitize_text_field($data['transaction_id'] ?? $body['transaction_id'] ?? $body['transactionId'] ?? '');
            $reference      = sanitize_text_field($data['reference']      ?? $data['reference_code']  ?? $body['reference']    ?? $body['reference_code'] ?? $body['referenceCode'] ?? '');

            $this->log_debug('JJuma Pay: parsed checkout session.', [
                'request_url'    => $request_url,
                'http_status'    => $status,
                'checkout_url'   => $payment_url,
                'transaction_id' => $transaction_id,
                'reference'      => $reference,
            ]);

            return [
                'payment_url'    => $payment_url,
                'transaction_id' => $transaction_id,
                'reference'      => $reference,
                'status_code'    => $status,
                'response_body'  => $body,
            ];
        }

        public function force_default_gateway($gateways) {
            if (is_admin()) {
                return $gateways;
            }
            if (count($gateways) === 1 && isset($gateways['jjuma_pay'])) {
                if (WC()->session && WC()->session->get('chosen_payment_method') !== 'jjuma_pay') {
                    WC()->session->set('chosen_payment_method', 'jjuma_pay');
                }
            }
            return $gateways;
        }

        public function enqueue_checkout_scripts() {
            if (is_checkout() && !is_order_received_page()) {
                if ($this->enabled === 'yes') {
                    wp_add_inline_script('jquery', '
                        jQuery(function($) {
                            function forceJjumaPayRadio() {
                                var $input = $("#payment_method_jjuma_pay[type=\'hidden\']");
                                if ($input.length) {
                                    var $new_input = $("<input type=\'radio\' class=\'input-radio\' name=\'payment_method\' id=\'payment_method_jjuma_pay\' value=\'jjuma_pay\' checked=\'checked\' style=\'display: inline-block !important;\' />");
                                    $input.replaceWith($new_input);
                                }
                            }
                            $(document).on("updated_checkout payment_method_selected", forceJjumaPayRadio);
                            forceJjumaPayRadio();
                        });
                    ');
                }
            }
        }
    }
}
