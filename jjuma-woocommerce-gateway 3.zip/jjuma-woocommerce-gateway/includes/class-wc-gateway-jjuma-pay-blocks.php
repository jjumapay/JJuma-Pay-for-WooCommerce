<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('JJuma_WooCommerce_Gateway_Blocks') && class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
    class JJuma_WooCommerce_Gateway_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
        protected $name = 'jjuma_pay';

        public function initialize() {
            $this->settings = get_option('woocommerce_' . JJuma_WooCommerce_Gateway_Plugin::GATEWAY_ID . '_settings', []);
        }

        public function is_active() {
            return !empty($this->settings['enabled']) && wc_string_to_bool((string) $this->settings['enabled']);
        }

        public function get_payment_method_script_handles() {
            $handle = 'jjuma-woocommerce-gateway-blocks';
            $script_url = plugins_url('../assets/js/blocks.js', __FILE__);
            wp_register_script(
                $handle,
                $script_url,
                ['wp-element', 'wp-html-entities', 'wc-blocks-registry', 'wc-settings', 'wp-i18n'],
                '1.0.0',
                true
            );
            return [$handle];
        }

        public function get_payment_method_data() {
            return [
                'title' => $this->settings['title'] ?? 'JJuma Pay',
                'description' => $this->settings['description'] ?? 'Pay securely using JJuma Pay.',
                'icon_url' => $this->settings['icon_url'] ?? '',
                'supports' => ['products', 'refunds'],
            ];
        }
    }

    add_action('woocommerce_blocks_payment_method_type_registration', function($payment_method_registry) {
        if (class_exists('JJuma_WooCommerce_Gateway_Blocks')) {
            $payment_method_registry->register(new JJuma_WooCommerce_Gateway_Blocks());
        }
    });
}
